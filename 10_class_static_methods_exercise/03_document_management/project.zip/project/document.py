from .category import Category
from .topic import Topic


class Document:
    def __init__(self, doc_id, category_id, topic_id, file_name):
        self.id = doc_id
        self.category_id = category_id
        self.topic_id = topic_id
        self.file_name = file_name
        self.tags:list = []

    @classmethod
    def from_instances(cls, doc_id, category: Category, topic: Topic, file_name):
        return cls(doc_id, category.id, topic.id, file_name)

    def add_tag(self, tag_content):
        if tag_content not in self.tags:
            self.tags.append(tag_content)

    def remove_tag(self, tag_content):
        if tag_content in self.tags:
            self.tags.remove(tag_content)

    def edit(self, file_name):
        self.file_name = file_name

    def __repr__(self):
        return (f"Document {self.id}: {self.file_name}; "
                f"category {self.category_id}, "
                f"topic {self.topic_id}, "
                f"tags: {', '.join(t for t in self.tags)}")